package com.consumer.controller;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.consumer.entity.FacebookUser;

@RestController
public class ConsumerController {
	
	@RequestMapping("about")
	public void aboutConsume() {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		String email = null;
		
		try {
			response = restTemplate.exchange("http://localhost:9000/about", HttpMethod.GET, setHeader(email), String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("search")
	public void searchConsume(@RequestParam String name) {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		
		try {
			response = restTemplate.postForEntity("http://localhost:9000/search", user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("edit")
	public void editConsume(@RequestParam String name, @RequestParam String email, @RequestParam String password) {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		try {
			response = restTemplate.postForEntity("http://localhost:9000/edit", user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("create")
	public void createConsume(@RequestParam String name, @RequestParam String email, @RequestParam String password) {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		try {
			response = restTemplate.postForEntity("http://localhost:9000/create", user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("view")
	public void viewConsume(@RequestParam String email) {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setEmail(email);
		
		try {
			response = restTemplate.postForEntity("http://localhost:9000/view", user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("delete")
	public void deleteConsume(@RequestParam String email) {
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setEmail(email);
		
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<FacebookUser> entity = new HttpEntity<FacebookUser>(user, headers);

		
		try {
			response = restTemplate.exchange("http://localhost:9000/delete", HttpMethod.DELETE, entity, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println(response.getBody());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HttpEntity setHeader(String email) throws IOException {
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		
		if (email != null)
			headers.add("Email", email);
		
		return new HttpEntity(headers);
	}
}
