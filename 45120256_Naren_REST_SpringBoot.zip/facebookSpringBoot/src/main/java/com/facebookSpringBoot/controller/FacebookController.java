package com.facebookSpringBoot.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.facebookSpringBoot.entity.FacebookUser;
import com.facebookSpringBoot.service.FacebookServiceInterface;

@RestController
public class FacebookController {
	
	@Autowired
	private FacebookServiceInterface fs;
	
	@GetMapping("about")
	public String about() {
		
		String ab = "ABOUT\nEnter keyword in URL to redirect:\n\n";
		ab += "create- Create profile\nedit- Edit profile\nview- View profile";
		ab += "\nsearch- Search profiles\ndelete- Delete profile";
		
		return ab;
	}
	
	@PostMapping("create")
	public String createProfile(@RequestBody FacebookUser u) {
		
		return fs.createProfile(u);
	}
	
	@PutMapping("edit")
	public String editProfile(@RequestBody FacebookUser u) {
		
		return fs.editProfile(u);
	}
	
	@PostMapping("view")
	public String viewProfile(@RequestBody FacebookUser u) {
		
		FacebookUser res = fs.viewProfile(u);
		
		if(res == null)
			return "No profile found";
		
		String profile = "Name: " + res.getName() + "\nEmail: " + res.getEmail();
		return profile;
	}
	
	@PostMapping("search")
	public String searchProfile(@RequestBody FacebookUser u) {
		
		ArrayList<FacebookUser> res = fs.searchProfile(u);
		
		String profiles = "";
		
		if(res == null)
			return "Search did not return anything";
		
		for(FacebookUser x: res) {
			profiles += "Name: " + x.getName() + "\nEmail: " + x.getEmail();
			profiles += "\n\n";
		}
		
		return profiles;
	}
	
	@DeleteMapping("delete")
	public String deleteProfile(@RequestBody FacebookUser u) {
		
		return fs.deleteProfile(u);
	}
}
