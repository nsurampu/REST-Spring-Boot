package com.facebookSpringBoot.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.facebookSpringBoot.entity.FacebookUser;

@Repository
public class FacebookDAO implements FacebookDAOInterface {

	@Override
	public String createProfileDAO(FacebookUser u) {
		
		Connection con;
		PreparedStatement ps;

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			
			con = DriverManager.getConnection(
				"jdbc:derby:c:/firstdb1;create=true", "naren", "naren"
			);
			
			ps = con.prepareStatement(
				"insert into fbspringboot values(?, ?, ?)"
			);
			ps.setString(1, u.getName());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPassword());
		}
		catch(Exception e) {
			e.printStackTrace();
			return "Unable to create profile. Try again";
		}

		int i = 0;
		try {
			i = ps.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}

		if(i > 0)
			return "Profile created successfuly";
		
		return "Unable to create profile. Try again";
	}

	@Override
	public String editProfileDAO(FacebookUser u) {
		
		Connection con;
		PreparedStatement ps;

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			
			con = DriverManager.getConnection(
				"jdbc:derby:c:/firstdb1;create=true", "naren", "naren"
			);
			
			ps = con.prepareStatement(
				"update fbspringboot set name=? and password=? where email=?"
			);
			ps.setString(1, u.getName());
			ps.setString(2, u.getPassword());
			ps.setString(3, u.getEmail());
		}
		catch(Exception e) {
			e.printStackTrace();
			return "Unable to edit profile. Try again";
		}

		int i = 0;
		try {
			i = ps.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		if(i > 0)
			return "Profile edited successfuly";
		
		return "Unable to edit profile. Try again";
	}

	@Override
	public FacebookUser viewProfileDAO(FacebookUser u) {
		
		Connection con;
		PreparedStatement ps;

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection(
			"jdbc:derby:c:/firstdb1;create=true", "naren", "naren"
			);
			
			ps = con.prepareStatement(
				"select name, email, password from fbspringboot where email=?"
			);
			ps.setString(1, u.getEmail());
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}

		ResultSet rs = null;

		try {
			rs = ps.executeQuery();	
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		try {
			if(!rs.next())
				return null;

			FacebookUser wn = new FacebookUser();
			
			wn.setName(rs.getString(1));
			wn.setEmail(rs.getString(2));
			wn.setPassword(rs.getString(3));
			
			return wn;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ArrayList<FacebookUser> searchProfileDAO(FacebookUser u) {
		
		Connection con;
		PreparedStatement ps;

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			
			con = DriverManager.getConnection(
				"jdbc:derby:c:/firstdb1;create=true", "naren", "naren"
			);

			ps = con.prepareStatement(
				"select name, email from fbspringboot where name=?"
			);
			ps.setString(1, u.getName());
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}

		ArrayList<FacebookUser> fl = new ArrayList<FacebookUser>();

		ResultSet rs = null;

		try {
			rs = ps.executeQuery();	
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		try {
			while(rs.next()) {
				FacebookUser fx = new FacebookUser();
				fx.setName(rs.getString(1));
				fx.setEmail(rs.getString(2));
				fl.add(fx);
			}
	
			return fl;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String deleteProfileDAO(FacebookUser u) {
		
		Connection con;
		PreparedStatement ps;

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			
			con = DriverManager.getConnection(
				"jdbc:derby:c:/firstdb1;create=true", "naren", "naren"
			);
			
			ps = con.prepareStatement(
				"delete from fbspringboot where email=?"
			);
			ps.setString(1, u.getEmail());
		}
		catch(Exception e) {
			e.printStackTrace();
			return "Unable to delete profile. Try again";
		}

		int i = 0;
		
		try {
			i = ps.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		if(i > 0)
			return "Profile deleted successfuly";
		
		return "Unable to delete profile. Try again";
	}
}
