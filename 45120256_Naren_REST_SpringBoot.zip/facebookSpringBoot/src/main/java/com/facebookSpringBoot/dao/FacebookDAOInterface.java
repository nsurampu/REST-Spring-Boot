package com.facebookSpringBoot.dao;

import java.util.ArrayList;

import com.facebookSpringBoot.entity.FacebookUser;

public interface FacebookDAOInterface {
	
	public String createProfileDAO(FacebookUser u);
	public String editProfileDAO(FacebookUser u);
	public FacebookUser viewProfileDAO(FacebookUser u);
	public ArrayList<FacebookUser> searchProfileDAO(FacebookUser u);
	public String deleteProfileDAO(FacebookUser u);
}
