package com.facebookSpringBoot.service;

import java.util.ArrayList;

import com.facebookSpringBoot.entity.FacebookUser;

public interface FacebookServiceInterface {
	
	public String createProfile(FacebookUser u);
	public String editProfile(FacebookUser u);
	public FacebookUser viewProfile(FacebookUser u);
	public ArrayList<FacebookUser> searchProfile(FacebookUser u);
	public String deleteProfile(FacebookUser u);
}
