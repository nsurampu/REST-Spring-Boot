package com.facebookSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacebookSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
