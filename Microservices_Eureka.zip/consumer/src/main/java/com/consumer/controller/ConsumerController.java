package com.consumer.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.consumer.entity.FacebookUser;

@RestController
public class ConsumerController {
	
	@Autowired
	private DiscoveryClient discoveryClient;   // Used to connect to Eureka Server
	                
	@RequestMapping("about")
	public void aboutConsume() {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/about";
				
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		String email = null;
		
		try {
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, setHeader(email), String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("search")
	public void searchConsume(@RequestParam String name) {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/search";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		
		try {
			response = restTemplate.postForEntity(baseUrl, user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("edit")
	public void editConsume(@RequestParam String name, @RequestParam String email, @RequestParam String password) {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/edit";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		try {
			response = restTemplate.postForEntity(baseUrl, user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("create")
	public void createConsume(@RequestParam String name, @RequestParam String email, @RequestParam String password) {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/create";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		
		try {
			response = restTemplate.postForEntity(baseUrl, user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("view")
	public void viewConsume(@RequestParam String email) {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/view";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setEmail(email);
		
		try {
			response = restTemplate.postForEntity(baseUrl, user, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	@RequestMapping("delete")
	public void deleteConsume(@RequestParam String email) {
		
		List<ServiceInstance> instances = discoveryClient.getInstances("facebookProducer");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/delete";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		FacebookUser user = new FacebookUser();
		user.setEmail(email);
		
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<FacebookUser> entity = new HttpEntity<FacebookUser>(user, headers);

		
		try {
			response = restTemplate.exchange(baseUrl, HttpMethod.DELETE, entity, String.class);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println(response.getBody());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HttpEntity setHeader(String email) throws IOException {
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		
		if (email != null)
			headers.add("Email", email);
		
		return new HttpEntity(headers);
	}
}
