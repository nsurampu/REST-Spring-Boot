package com.facebookSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class FacebookSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacebookSpringBootApplication.class, args);
	}

}
