package com.facebookSpringBoot.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.facebookSpringBoot.dao.FacebookDAOInterface;
import com.facebookSpringBoot.entity.FacebookUser;

@Service
public class FacebookService implements FacebookServiceInterface {

	@Autowired
	private FacebookDAOInterface fd;
	
	@Override
	public String createProfile(FacebookUser u) {
		
		return fd.createProfileDAO(u);
	}

	@Override
	public String editProfile(FacebookUser u) {
		
		return fd.editProfileDAO(u);
	}

	@Override
	public FacebookUser viewProfile(FacebookUser u) {
		
		return fd.viewProfileDAO(u);
	}

	@Override
	public ArrayList<FacebookUser> searchProfile(FacebookUser u) {
		
		return fd.searchProfileDAO(u);
	}

	@Override
	public String deleteProfile(FacebookUser u) {
		
		return fd.deleteProfileDAO(u);
	}

}
